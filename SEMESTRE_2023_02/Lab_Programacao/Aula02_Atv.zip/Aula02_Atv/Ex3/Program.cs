﻿  
            
double altura = 3.45;

            
Console.WriteLine("A altura é: " + altura);
    
