﻿      
   string nome = "Maria";

            
            Console.WriteLine("O nome é: " + nome);
        
