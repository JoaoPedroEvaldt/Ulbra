﻿
            DateTime nascimento = new DateTime(1985, 12, 10);

           
            Console.WriteLine("A data de nascimento é: " + nascimento.ToString("10/12/1985"));
        
    

