﻿
         
     int idade = 35;

            
      Console.WriteLine("A idade é: " + idade);
        
