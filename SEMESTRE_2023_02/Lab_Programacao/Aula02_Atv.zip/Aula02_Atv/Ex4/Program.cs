﻿


            DateTime data = new DateTime(1999, 9, 4);

           
            Console.WriteLine("A data é: " + data.ToString("04/09/1999"));
        
    
