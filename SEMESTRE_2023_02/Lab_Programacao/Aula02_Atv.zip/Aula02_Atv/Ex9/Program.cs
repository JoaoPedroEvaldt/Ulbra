﻿
double largura = 2.20;

            
Console.WriteLine("A largura é: " + largura);
        
    

