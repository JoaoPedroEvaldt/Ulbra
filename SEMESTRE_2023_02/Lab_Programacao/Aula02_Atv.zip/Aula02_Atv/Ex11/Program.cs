﻿

double? temperatura = 22.5;

            
 Console.WriteLine("A temperatura é: " + temperatura);
        
    
