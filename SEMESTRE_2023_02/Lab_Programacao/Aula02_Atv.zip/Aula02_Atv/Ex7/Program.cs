﻿
           
double? peso = 6.85;

            
 Console.WriteLine("O peso é: " + peso);
        
    

