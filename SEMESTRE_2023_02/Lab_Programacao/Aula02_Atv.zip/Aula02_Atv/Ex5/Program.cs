﻿
 int Ano = 12;
        
            
  Console.WriteLine("O valor da constante é: " + Ano);
        
    
