﻿
string cidade = "São Paulo";

         
Console.WriteLine("O nome da cidade é: " + cidade );

    

