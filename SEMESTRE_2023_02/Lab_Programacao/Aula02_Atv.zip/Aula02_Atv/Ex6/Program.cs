﻿
double? nota = 7.80;

            
 Console.WriteLine("A nota é: " + nota);
        

